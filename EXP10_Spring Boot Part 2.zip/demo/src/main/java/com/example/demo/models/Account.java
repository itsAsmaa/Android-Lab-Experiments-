package com.example.demo.models;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "account")
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "account_id")
    private Integer id = null;

    @Column(name = "account_codeNumber")
    private String codeNumber;

    @ManyToOne
    @JoinColumn(name = "user_id")
    @JsonBackReference("user-accounts")
    private User user;

    // Constructors
    public Account() {}

    public Account(String codeNumber) {
        this.codeNumber = codeNumber;
    }

    // Getters & Setters
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getCodeNumber() { return codeNumber; }
    public void setCodeNumber(String codeNumber) { this.codeNumber = codeNumber; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
}
