package com.example.demo.models;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "user_id")
    private Integer id = null;

    @Column(nullable = false, unique = true)
    private String userName;

    // One-to-One: each user has one office
    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL)
    @JsonManagedReference("user-office")
    private Office office;

    // One-to-Many: one user has many accounts
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "user")
    @JsonManagedReference("user-accounts")
    private List<Account> accounts = new ArrayList<>();

    // Many-to-Many: a user can enroll in many courses
    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(
        name = "user_course",
        joinColumns = @JoinColumn(name = "user_id"),
        inverseJoinColumns = @JoinColumn(name = "course_id")
    )
    @JsonManagedReference("user-courses")
    private List<Course> courses = new ArrayList<>();

    // Constructors
    public User() {}

    public User(Integer id, String userName) {
        this.id = id;
        this.userName = userName;
    }

    // Getters & Setters
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }

    public Office getOffice() { return office; }
    public void setOffice(Office office) { this.office = office; }

    public List<Account> getAccounts() { return accounts; }
    public void setAccounts(List<Account> accounts) { this.accounts = accounts; }

    public List<Course> getCourses() { return courses; }
    public void setCourses(List<Course> courses) { this.courses = courses; }
}
