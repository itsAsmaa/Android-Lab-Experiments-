package com.example.demo.controllers;

import com.example.demo.models.User;
import com.example.demo.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    UserService service;

    // GET http://localhost:8081/users
    @GetMapping
    public List<User> getAllUsers() {
        return service.getAll();
    }

    // GET http://localhost:8081/users/1
    @GetMapping("/{id}")
    public Optional<User> getUserById(@PathVariable Integer id) {
        return service.getById(id);
    }

    // POST http://localhost:8081/users
    @PostMapping
    public String addUser(@RequestBody User user) {
        return service.addUser(user);
    }

    // PUT http://localhost:8081/users/1
    @PutMapping("/{id}")
    public String updateUser(@PathVariable Integer id, @RequestBody User user) {
        return service.updateUser(id, user);
    }

    // DELETE http://localhost:8081/users/1
    @DeleteMapping("/{id}")
    public String deleteUser(@PathVariable Integer id) {
        return service.deleteUser(id);
    }
}
