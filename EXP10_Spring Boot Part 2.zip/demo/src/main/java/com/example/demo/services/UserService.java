package com.example.demo.services;

import com.example.demo.models.User;
import com.example.demo.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    UserRepository userRepository;

    // GET ALL users
    public List<User> getAll() {
        return userRepository.findAll();
    }

    // GET ONE user by ID
    public Optional<User> getById(Integer id) {
        return userRepository.findById(id);
    }

    // CREATE a new user
    public String addUser(User user) {
        userRepository.save(user);
        return "User added successfully";
    }

    // UPDATE an existing user's username
    public String updateUser(Integer id, User updatedUser) {
        Optional<User> existing = userRepository.findById(id);
        if (existing.isPresent()) {
            User user = existing.get();
            user.setUserName(updatedUser.getUserName());
            userRepository.save(user);
            return "User updated successfully";
        }
        return "User not found";
    }

    // DELETE a user by ID
    public String deleteUser(Integer id) {
        if (userRepository.existsById(id)) {
            userRepository.deleteById(id);
            return "User deleted successfully";
        }
        return "User not found";
    }
}
