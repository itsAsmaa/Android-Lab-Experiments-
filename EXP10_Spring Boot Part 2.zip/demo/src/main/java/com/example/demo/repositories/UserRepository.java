package com.example.demo.repositories;

import com.example.demo.models.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Integer> {
    // JpaRepository provides: findAll, findById, save, deleteById, existsById, count
    // No implementation needed — Spring Data JPA creates it automatically at runtime
}
