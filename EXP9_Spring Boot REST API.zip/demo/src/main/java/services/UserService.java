package services;

import java.util.ArrayList;
import java.util.Arrays;
import org.springframework.stereotype.Service;
import models.User;

@Service
public class UserService {

    // In-memory list acting as our "database" for now
    private ArrayList<User> userList = new ArrayList<>(Arrays.asList(
            new User("Tarek", "tarek123", "Tarek@gmail.com"),
            new User("Saleh", "saleh111", "s@hotmail.com")
    ));

    // Return all users
    public ArrayList<User> getUserList() {
        return this.userList;
    }

    // Add a new user
    public boolean addUserToUserList(User user) {
        return userList.add(user);
    }

    // Delete user by username
    public boolean deleteUserFromList(String userName) {
        return userList.removeIf(u -> u.getUserName().equals(userName));
    }

    // Update user by username
    public boolean updateUser(String userName, User updatedUser) {
        for (User u : userList) {
            if (u.getUserName().equals(userName)) {
                u.setName(updatedUser.getName());
                u.setEmail(updatedUser.getEmail());
                u.setUserName(updatedUser.getUserName());
                return true;
            }
        }
        return false;
    }
}