package com.example.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.model.User;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RestController
public class UserController {

    private static List<User> userList = new ArrayList<>(Arrays.asList(
        new User("Tarek", "tarek123", "Tarek@gmail.com"),
        new User("Saleh", "saleh111", "s@hotmail.com")
    ));

    @GetMapping("/users")
    public List<User> listUsers() {
        return userList;
    }

    @PostMapping("/users")
    public boolean createUser(@RequestBody User user) {
        return userList.add(user);
    }

    @DeleteMapping("/users/{userName}")
    public boolean deleteUser(@PathVariable String userName) {
        return userList.removeIf(user -> user.getUserName().equals(userName));
    }

    @PutMapping("/users/{userName}")
    public boolean updateUser(@PathVariable String userName, @RequestBody User user) {
        for (int i = 0; i < userList.size(); i++) {
            if (userList.get(i).getUserName().equals(userName)) {
                userList.set(i, user);
                return true;
            }
        }
        return false;
    }
}

