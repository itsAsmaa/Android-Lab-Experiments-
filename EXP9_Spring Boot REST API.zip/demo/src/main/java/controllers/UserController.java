package controllers;



import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import models.User;
import services.UserService;

@RestController
public class UserController {

    @Autowired
    UserService service;

    // GET all users → localhost:8080/users
    @RequestMapping(method = RequestMethod.GET, value = "/users")
    public ArrayList<User> getAllUsers() {
        return service.getUserList();
    }

    // POST add a user → localhost:8080/users
    @RequestMapping(method = RequestMethod.POST, value = "/users")
    public boolean addUser(@RequestBody User user) {
        return service.addUserToUserList(user);
    }

    // DELETE a user → localhost:8080/users/tarek123
    @RequestMapping(method = RequestMethod.DELETE, value = "/users/{userName}")
    public boolean deleteUser(@PathVariable String userName) {
        return service.deleteUserFromList(userName);
    }

    // PUT update a user → localhost:8080/users/saleh111
    @RequestMapping(method = RequestMethod.PUT, value = "/users/{userName}")
    public boolean updateUser(@RequestBody User user, @PathVariable String userName) {
        return service.updateUser(userName, user);
    }
}