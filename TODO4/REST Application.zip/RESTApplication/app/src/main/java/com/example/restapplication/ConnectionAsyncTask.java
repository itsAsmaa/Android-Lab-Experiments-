package com.example.restapplication;

import android.app.Activity;
import android.os.AsyncTask;

import java.net.URL;
import java.util.List;

public class ConnectionAsyncTask extends AsyncTask<URL, String, String> {

    Activity activity;

    public ConnectionAsyncTask(Activity activity) {
        this.activity = activity;
    }

    // Runs on UI thread BEFORE background work starts
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        ((MainActivity) activity).setButtonText("Connecting...");
        ((MainActivity) activity).setProgress(true);   // show spinner
    }

    // Runs on BACKGROUND thread — do NOT touch UI here
    @Override
    protected String doInBackground(URL... params) {
        if (params != null && params.length > 0) {
            return HttpManager.getData(params[0]);
        }
        return null;
    }

    // Runs on UI thread AFTER background work finishes
    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        ((MainActivity) activity).setProgress(false);  // hide spinner
        ((MainActivity) activity).setButtonText("Connected ✓");

        List<Student> students = StudentJsonParser.getObjectFromJson(s);
        ((MainActivity) activity).fillStudents(students);
    }
}
