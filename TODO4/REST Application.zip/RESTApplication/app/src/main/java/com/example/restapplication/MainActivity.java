package com.example.restapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.net.URL;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Button button;
    LinearLayout linearLayout;

    // Your Mocki.io API URL (create your own at https://mocki.io/fake-json-api)
    private static final String API_URL =
            "https://mocki.io/v1/649b053c-38aa-45ba-a03a-e5f32814e4e7";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setProgress(false); // hide spinner initially

        button = findViewById(R.id.button);
        linearLayout = findViewById(R.id.layout);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Launch the async network task
                ConnectionAsyncTask task = new ConnectionAsyncTask(MainActivity.this);
                try {
                    URL url = new URL(API_URL);
                    task.execute(url);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }

            }
        });
    }

    // Called from AsyncTask to update button label
    public void setButtonText(String text) {
        button.setText(text);
    }

    // Called from AsyncTask to show/hide the progress bar
    public void setProgress(boolean visible) {
        ProgressBar progressBar = findViewById(R.id.progressBar);
        progressBar.setVisibility(visible ? View.VISIBLE : View.GONE);
    }

    // Called from AsyncTask to populate the LinearLayout with student data
    public void fillStudents(List<Student> students) {
        LinearLayout layout = findViewById(R.id.layout);
        layout.removeAllViews(); // clear old results

        if (students == null) return;

        for (int i = 0; i < students.size(); i++) {
            TextView textView = new TextView(this);
            textView.setText(students.get(i).toString());
            textView.setTextSize(16);
            layout.addView(textView);
        }
    }
}