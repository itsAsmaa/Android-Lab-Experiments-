package com.example.restapplication;
public class Student {

    private int ID;
    private String name;
    private Double age;

    // Empty constructor
    public Student() {}

    // Constructor with parameters
    public Student(int ID, String name, Double age) {
        this.ID = ID;
        this.name = name;
        this.age = age;
    }

    // Getters
    public int getID()       { return ID; }
    public String getName()  { return name; }
    public Double getAge()   { return age; }

    // Setters
    public void setID(int ID)         { this.ID = ID; }
    public void setName(String name)  { this.name = name; }
    public void setAge(Double age)    { this.age = age; }

    @Override
    public String toString() {
        return "Student{" +
                "\nID= "   + ID   +
                "\nname= " + name +
                "\nage= "  + age  +
                '\n' + '}' + '\n';
    }
}